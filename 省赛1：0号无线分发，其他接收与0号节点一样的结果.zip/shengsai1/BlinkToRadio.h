#ifndef BLINKTORADIO_H
#define BLINKTORADIO_H
	typedef nx_struct radio_msg {
	  nx_uint16_t counter;
	} radio_msg_t;

	typedef nx_struct serial_msg {
	  nx_uint16_t counter;
	} serial_msg_t;
  

#endif