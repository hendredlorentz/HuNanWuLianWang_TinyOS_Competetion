#ifndef TEST_SERIAL_H
#define TEST_SERIAL_H

typedef nx_struct test_serial_msg {
  nx_uint16_t id[12];
  nx_uint16_t count;
} test_serial_msg_t;

#endif