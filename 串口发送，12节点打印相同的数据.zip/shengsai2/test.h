#ifndef BLINKTORADIO_H
#define BLINKTORADIO_H

enum {
  AM_BLINKTORADIO = 6,    //组号
  TIMER_PERIOD_MILLI = 250
};

//无线通信包
typedef nx_struct RadioMsg {
    nx_uint8_t data1;
    
} RadioMsg;

//串口通信包
typedef nx_struct serial_msg_t {
    nx_uint8_t data1;
    
} serial_msg_t;

#endif