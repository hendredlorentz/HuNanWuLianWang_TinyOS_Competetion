#ifndef TEST_H
#define TEST_H
#include <AM.h>
typedef nx_struct test_fy_msg {
    nx_uint8_t flag;	
    nx_uint8_t count;	
    nx_uint8_t data;		
} test_fy_msg_t;

typedef nx_struct test_serial_msg {
  nx_uint8_t id;
  nx_uint8_t data;	
} test_serial_msg_t;

enum {
 AM_TESTNETWORKMSG = 0x05,
 SAMPLE_RATE_KEY = 0x1,
 CL_TEST = 0xee,
 TEST_NETWORK_QUEUE_SIZE = 8,
};

#endif